# jgcj
采集源接口[影视站之家网站](https://www.yszzq.com/tags/xmlcjjk/)的结果,最后给v影用下面的第一个链接，给t——v-b-o-x用第二个链接,影视大全用第三个链接(需要打开后复制)，zypc版使用第四个链接，libre使用第五个链接
```
https://a.wokaotianshi.eu.org/jgcj/zyvying.json
```
```
https://a.wokaotianshi.eu.org/jgcj/zytvbox.json
```
```
https://a.wokaotianshi.eu.org/jgcj/ysdqbox.json
```
```
https://a.wokaotianshi.eu.org/jgcj/zypcbox.json
```
```
https://a.wokaotianshi.eu.org/jgcj/libretv.json
```
